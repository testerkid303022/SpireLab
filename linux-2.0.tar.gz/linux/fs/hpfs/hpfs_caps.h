unsigned hpfs_char_to_linux (unsigned c);
unsigned hpfs_char_to_lower_linux (unsigned c);
unsigned hpfs_char_to_upper_linux (unsigned c);
unsigned linux_char_to_upper_linux (unsigned c);
